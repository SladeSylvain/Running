autor: Pavel Kutejnikov

game: Caterpillarnoid
https://store.steampowered.com/app/1349920/Caterpillarnoid/

license: cc0 / public domain